<html>

<link rel="stylesheet" href="layout.css">
<body>
<div id="content">
	<h1 >
	Welcome to our shop
	</h1>
	<p>
	Our shop is located on the dream street of Toumpa, Thessaloniki. We offer literature in English, French, Italian, Spanish, German, Chinese, and, of course, Greek. We focus on new and used books of modern classic fiction and non-fiction but also offer selections of poetry, philosophy, art, and all things Greek interest.
	In recent years we’ve begun selling rare antiquarian books and collectors’ first editions, and also printing our own books and posters through our publishing outfit, Paravion Press. We are open every day and we look forward to welcoming you to our little bookstore overlooking the Thessaloniki caldera.

	<?php

		print "Hello from php";
		?>
	</p>
</div>
</body>
</html>