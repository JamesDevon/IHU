<form method="post" action="index.php">
Username: <input name="username"/>
<br/>
Password: <input name="pass" type="password"/>
<br/>
<input type="submit" value="LOGIN" />
<input name="p" value="do_login" type="hidden">
</form>